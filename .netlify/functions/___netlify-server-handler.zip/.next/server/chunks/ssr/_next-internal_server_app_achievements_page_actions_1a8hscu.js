module.exports=[24840,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_achievements_page_actions_1a8hscu.js.map