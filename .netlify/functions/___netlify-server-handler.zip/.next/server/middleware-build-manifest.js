globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/1tXMNGBMyanMMpchxVNEo/_buildManifest.js",
    "static/1tXMNGBMyanMMpchxVNEo/_ssgManifest.js",
    "static/1tXMNGBMyanMMpchxVNEo/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0jvhpaew_uadu.js",
    "static/chunks/24uyhvvmdi5sa.js",
    "static/chunks/36lm--m0zwqtj.js",
    "static/chunks/3l_w1b3jpywze.js",
    "static/chunks/turbopack-3_qx_7btgh738.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
